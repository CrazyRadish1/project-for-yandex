import pygame
import sys
import random
import os

pygame.init()

BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Летающая ракета")

rocket_image = pygame.image.load("rocket.png")
rocket_image = pygame.transform.scale(rocket_image, (80, 80))

rocket_rect = rocket_image.get_rect()
rocket_rect.x = WIDTH // 2 - rocket_rect.width // 2
rocket_rect.y = HEIGHT - rocket_rect.height - 10
rocket_speed = 5

bullet_width, bullet_height = 5, 15
bullet_speed = 7
bullets = []

enemy_image = pygame.image.load("enemy.png")
enemy_image = pygame.transform.scale(enemy_image, (50, 50))
enemy_speed = 3
enemies = []

score = 100
font = pygame.font.Font(None, 36)
skipass = 0
highscore_file = "highscore.txt"

stars = [(random.randint(0, WIDTH), random.randint(0, HEIGHT)) for _ in range(500)]


def load_image(name, colorkey=None):
    fullname = os.path.join(name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


FPS = 50


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["КОСМОБОЙ", "",
                  "Правила игры",
                  "Если вы пропустите больше 25 кораблей, вы проиграете",
                  "Екатерина Юрьевна",
                  "Мы вас любим!"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(FPS)


def exit_screen():
    intro_text = ["КОСМОБОЙ", "",
                  "Вы проиграли",
                  "Нажмите где-нибудь, чтобы выйти",
                  ]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(FPS)


def draw_bullets(bullets):
    for bullet in bullets:
        pygame.draw.rect(screen, WHITE, [bullet[0], bullet[1], bullet_width, bullet_height])


def draw_enemies(enemies):
    for enemy in enemies:
        screen.blit(enemy_image, (enemy[0], enemy[1]))


def draw_stars(stars):
    for star in stars:
        pygame.draw.circle(screen, GREEN, star, 1)


def draw_score(score, highscore):
    score_text = font.render(f"Счёт: {score}  Рекорд: {highscore}", True, WHITE)
    screen.blit(score_text, [10, 10])


def save_highscore():
    with open(highscore_file, "w") as file:
        file.write(str(highscore))


def load_highscore():
    try:
        with open(highscore_file, "r") as file:
            return int(file.read())
    except FileNotFoundError:
        return 0


highscore = load_highscore()
clock = pygame.time.Clock()
game_running = True
start_screen()

if __name__ == '__main__':
    while game_running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    rocket_rect.x -= rocket_speed
                elif event.key == pygame.K_RIGHT:
                    rocket_rect.x += rocket_speed
                elif event.key == pygame.K_SPACE:
                    bullet_x = rocket_rect.x + rocket_rect.width // 2 - bullet_width // 2
                    bullet_y = rocket_rect.y
                    bullets.append([bullet_x, bullet_y])

        for enemy in enemies:
            enemy[1] += enemy_speed

            if enemy[1] > HEIGHT:
                enemies.remove(enemy)
                skipass += 1
                if skipass == 25:
                    exit_screen()
                    sys.exit()

        if random.randint(0, 100) < 5:
            enemy_x = random.randint(0, WIDTH - 50)
            enemy_y = 0
            enemies.append([enemy_x, enemy_y])

        for bullet in bullets:
            bullet[1] -= bullet_speed

            if bullet[1] < 0:
                bullets.remove(bullet)

            for enemy in enemies:
                if (
                        bullet[0] < enemy[0] + 50
                        and bullet[0] + bullet_width > enemy[0]
                        and bullet[1] < enemy[1] + 50
                        and bullet[1] + bullet_height > enemy[1]
                ):
                    bullets.remove(bullet)
                    enemies.remove(enemy)
                    score += 10

        if score > highscore:
            highscore = score
            save_highscore()

        screen.fill(BLACK)
        draw_stars(stars)
        screen.blit(rocket_image, (rocket_rect.x, rocket_rect.y))
        draw_bullets(bullets)
        draw_enemies(enemies)
        draw_score(score, highscore)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()
